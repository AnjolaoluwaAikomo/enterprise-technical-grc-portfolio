# MapleBridge Financial Technology — Technical GRC Portfolio

> **SIMULATED — FICTIONAL CASE STUDY — NOT INDEPENDENT ASSURANCE**

This repository contains a **fictional Canadian B2B fintech** technical governance, risk and compliance portfolio. MapleBridge Financial Technology Inc. is an assumed Ontario-based **non-bank payment service provider** offering BridgeAPI payment-instruction integration, MatchLedger reconciliation and OpsConsole operations. It is **not** represented as a bank; no claim is made that it holds customer funds or settles transfers. All people, vendors, configurations, operational logs and interviews are fictional.

## Scope and baseline
- Company scenario, assumptions and exclusions: `governance/authoritative/F-01_*`
- Management, RACI, three lines of responsibility: `governance/authoritative/F-02_*`
- GCP architecture, PostgreSQL, Okta, Google Workspace, GitHub/Jira, backups, monitoring and CedarPay interface: `governance/authoritative/F-03_*`
- Identifiers and evidence governance: `governance/authoritative/F-04_*`
- Framework editions and licensing: `governance/authoritative/F-05_*`
- Frozen source-data baseline: `source-data/baseline/` with metadata in `evidence/metadata/`

**Simulated assessment:** 2026-09-01 through 2026-10-31. **Baseline:** 2026-09-30. **Remediation:** 2026-10-15 (reserved). **Retest:** 2026-10-30 (reserved). Original baseline source records have not been modified.

## Repository layout
| Path | Purpose |
|---|---|
| `source-data/` | Frozen synthetic source exports, dictionaries and future snapshots |
| `assessment/` | Future risks, controls, ITGC workpapers and vendor assurance |
| `automation/` | Future control-check code, unit tests and result files |
| `evidence/` | Provenance metadata and future referenced evidence |
| `reports/` | Reusable Word/PDF templates and later issued reports |
| `references/` | Official framework source notes, edition/access tracking |
| `governance/` | F-01–F-06 originals, QA, project tracker, deliverable index |

## Getting started
1. Review F-01 through F-05 originals under `governance/authoritative/`.
2. Run `python verify_baseline.py` from the repository root. It verifies 12 baseline CSV hashes against the original F-06 evidence index.
3. Use `governance/tracking/MapleBridge_F07_Project_Tracker_Templates_v1.0.xlsx` for the 67-step tracker, deliverable index, QA and blank workpapers.
4. For reports, copy a file from `reports/templates/`; fill IDs and source references and label the simulated nature of the work.
5. Proceed to A-01 only after the Foundation quality gate passes.

## Identifier and provenance rules
Canonical forms include `SYS-001`, `AST-001`, `RSK-001`, `CTRL-001`, `EV-001`, `TEST-001`, `FND-001`, `ACT-001`, `VEN-001`. Existing F-03 IDs (`SYS-01`, `AST-01`) are **legacy aliases**, not different records. The tracker uses a **namespaced key** (e.g., `FOUNDATION:F-01` vs `F:F-01`) because the plan reuses `F-01` in the Foundation and Module F. Do not confuse these steps.

The 12 baseline source CSVs are evidence inputs, **not control-test results**. No risk scores, control effectiveness conclusions, audit findings or remediation closure claims have been created.

## Evidence and framework limitations
The synthetic evidence pack was generated after its simulated observation dates; metadata distinguishes `observed_at` from `generated_at`. No production systems were accessed. The original SHA-256 manifest and F-06 evidence index are retained in `governance/authoritative/`; their original relative paths apply to the **original F-06 package**, while `verify_baseline.py` resolves the repository relocation.

NIST CSF 2.0 and SP 800-30 support governance/risk; AICPA Trust Services Criteria, ISO/IEC 27001:2022 and CSA CCM/CAIQ support control mapping. OSFI B-10/B-13 are **benchmarks**, not asserted legal obligations for a non-FRFI. Licensed framework content is not reproduced.

## Integrity, publication and ethics
No real employee, customer, banking, credential or sensitive records are included. Do not commit secrets, private keys or live tokens. A simulated portfolio workpaper is **not** an independent audit opinion, SOC 2 attestation, ISO certification or legal advice. The repository is a local **GitHub-ready skeleton**, not a claim that a public GitHub repository has already been created.

## Versioning
F-07 baseline: v1.0. Changes require a dated change-log entry and impact review. Existing F-01 through F-06 deliverables are copied unchanged.
